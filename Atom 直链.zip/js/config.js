// Site configuration - centralized URL management
window.siteConfig = {
    downloads: {
        apk: 'https://d6.qyshare.store/s/TBVWTxUNFVMOB1IFKFCVA50g8BGlVUKFCVA50gIaKFCVA50w8FDxpVUQBWGlEPKFCVA50KFCVA50RVDw8PKFCVA50KFCVA50FVURUbFVhERH9YREMVDRVYREQZRk5CWRlYRVKFCVA50VGxVYRER8Uk4VDRVCR1tYVlMYBQcFKFCVA50RgHKFCVA50xgGDhgBU1FWKFCVA501MOURpVKFCVA501IOGgNRBgUaVVQDUxpVKFCVA501IGB1YHKFCVA50QYFUwEZVV5ZFRsVVlQVDRUGBQQPBKFCVA509WBxpSDgMKFCVA50GgMHUg4aD1ZRURpTUg8BUwEPVFJUVFQVGxVZVlpSFQ0V0rmo0pqn0r2e0b68H9-2rdK4r9C-vx5oBhkHGQcZVkdcFRsVVFhZQ1JZQ2NOR1IVDRVWR0dbXlRWQ15YWRhBWVMZVllTRVheUxlHVlRcVlBSGlZFVF9eQVIVGxVWUxUNFQVVDwVVVVNRGg8HBQ4aKFCVA50wZWKFCVA50xoOKFCVA50QKFCVA50OGg4HVgECDgVUUQ8KFCVA50URVK',
        googlePlay: 'https://play.google.com/store/apps/details?id=net.lab.flying'
    }
};

// Apply download URLs to elements with data-download attribute
function initDownloadLinks() {
    const config = window.siteConfig.downloads;
    document.querySelectorAll('[data-download]').forEach(el => {
        const key = el.getAttribute('data-download');
        if (config[key]) {
            el.setAttribute('href', config[key]);
        }
    });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDownloadLinks);
} else {
    initDownloadLinks();
}
